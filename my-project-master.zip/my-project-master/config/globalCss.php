<?php

return [
    
'boot' => 'styles/bootstrap-4.1.3/bootstrap.css',
'font' => 'plugins/font-awesome-4.7.0/css/font-awesome.min.css',
'owl_c' =>'plugins/OwlCarousel2-2.2.1/owl.carousel.css',
'owl_t' =>'plugins/OwlCarousel2-2.2.1/owl.theme.default.css',
'ani' => 'plugins/OwlCarousel2-2.2.1/animate.css',
'main' =>'styles/main_styles.css',
'response' =>'styles/responsive.css'
];

?>
