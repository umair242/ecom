<?php
return [
'jquery' => 'js/jquery-3.2.1.min.js',
'pop' => 'styles/bootstrap-4.1.3/popper.js',
'boot' => 'styles/bootstrap-4.1.3/bootstrap.min.js',
'tween' => 'plugins/greensock/TweenMax.min.js',
'time' => 'plugins/greensock/TimelineMax.min.js',
'scroll' => 'plugins/scrollmagic/ScrollMagic.min.js',
'ani' => 'plugins/greensock/animation.gsap.min.js',
'scroll_t' => 'plugins/greensock/ScrollToPlugin.min.js',
'owl_c' => 'plugins/OwlCarousel2-2.2.1/owl.carousel.js',
'eas' => 'plugins/easing/easing.js',
'para' => 'plugins/parallax-js-master/parallax.min.js',
'iso' => 'plugins/Isotope/isotope.pkgd.min.js',
'fit' => 'plugins/Isotope/fitcolumns.js',
'custom' => 'js/custom.js'
    
    ];
?>