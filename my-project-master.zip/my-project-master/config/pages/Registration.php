<?php

return [
    'layout' => 'layouts.design_Reg',
    
    'headerCss' => [
        'boot',
      //  'response',
        'font',
        'owl_c',
        'owl_t',
        'ani',
        'main'
        
    ],
    'headerJs' =>[
        'jquery',
        'pop',
        'boot',
        'tween',
        'time',
        'scroll',
        'ani',
        'scroll_t',
        'owl_c',
        'eas',
        'para',
        'iso',
        'fit',
        'custom'
        
    ],
    'headSection' => [
       'head',        
    ],
    'LeftSection' => [
       
     //'Logo',
   //  'Nav',
     'Head_Extra',
     'Sidebar',
     'Menu',
         'User_Registration'
       ],
    'RightSection' => [
     //'Main_Slide',
      //'Cat',
      //'Box'
       ],
    
    'BodySection' => [
      
    // 'Product',
    // 'Newsletter',
       
      ],
    
    'FooterSection' => [
    // 'footer_logo', 
     //'contact',
     'Foot_Content',
    // 'Social',
     'Credit',
        
    ],
    
    'footerJs' =>[
        'jquery',
        'pop',
        'boot',
        'tween',
        'time',
        'scroll',
        'ani',
        'scroll_t',
        'owl_c',
        'eas',
        'para',
        'iso',
        'fit',
        'custom'
        
    ],
];

?>