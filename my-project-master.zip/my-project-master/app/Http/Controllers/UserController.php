<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends ViewCompilingController
{
  public function getRegistrationPage(){
     return $this->buildpages ('Registration');
      
//dd (config ('pages.home'));
//return view('home');
  }
  
}
